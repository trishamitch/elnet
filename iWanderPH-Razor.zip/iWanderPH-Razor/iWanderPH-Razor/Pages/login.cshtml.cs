using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace iWanderPH_Razor.Pages
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
